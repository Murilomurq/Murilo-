export const itemCategories = {
  alimentos: { name: 'Alimentos', icon: '🍎', color: '#FF6B6B' },
  limpeza: { name: 'Limpeza', icon: '🧼', color: '#4ECDC4' },
  bebidas: { name: 'Bebidas', icon: '🥤', color: '#45B7D1' },
  higiene: { name: 'Higiene', icon: '🧴', color: '#96CEB4' },
  padaria: { name: 'Padaria', icon: '🍞', color: '#FFEAA7' },
  acougue: { name: 'Açougue', icon: '🥩', color: '#FF8C8C' },
  outros: { name: 'Outros', icon: '🛒', color: '#F7DC6F' },
};

export const sampleItems = [
  { id: 1, name: 'Maçãs', category: 'alimentos', inCart: true, date: '2025-07-10', price: 5.50 },
  { id: 2, name: 'Detergente', category: 'limpeza', inCart: true, date: '2025-07-10', price: 2.30 },
  { id: 3, name: 'Refrigerante 2L', category: 'bebidas', inCart: false, date: '2025-07-10', price: 8.00 },
  { id: 4, name: 'Shampoo', category: 'higiene', inCart: false, date: '2025-07-10', price: 15.90 },
  { id: 5, name: 'Pão Francês', category: 'padaria', inCart: true, date: '2025-07-10', price: 4.00 },
  { id: 6, name: 'Peito de Frango (1kg)', category: 'acougue', inCart: false, date: '2025-07-10', price: 22.00 },
  { id: 7, name: 'Pilhas AA', category: 'outros', inCart: false, date: '2025-07-10', price: 12.50 },
  { id: 8, name: 'Arroz (5kg)', category: 'alimentos', inCart: true, date: '2025-07-10', price: 25.00 },
  { id: 9, name: 'Água Sanitária', category: 'limpeza', inCart: false, date: '2025-07-10', price: 5.00 },
  { id: 10, name: 'Suco de Laranja (1L)', category: 'bebidas', inCart: true, date: '2025-07-10', price: 9.50 },
  { id: 11, name: 'Sabonete', category: 'higiene', inCart: true, date: '2025-06-15', price: 3.20 },
  { id: 12, name: 'Leite (1L)', category: 'alimentos', inCart: true, date: '2025-06-15', price: 4.80 },
  { id: 13, name: 'Café (500g)', category: 'alimentos', inCart: true, date: '2025-06-15', price: 18.00 },
  { id: 14, name: 'Biscoitos', category: 'alimentos', inCart: true, date: '2025-05-20', price: 6.50 },
];