export const categories = [
  { id: 'alimentacao', name: 'Alimentação', icon: '🍽️', color: '#FF6B6B' },
  { id: 'transporte', name: 'Transporte', icon: '🚗', color: '#4ECDC4' },
  { id: 'moradia', name: 'Moradia', icon: '🏠', color: '#45B7D1' },
  { id: 'saude', name: 'Saúde', icon: '🏥', color: '#96CEB4' },
  { id: 'educacao', name: 'Educação', icon: '📚', color: '#FFEAA7' },
  { id: 'lazer', name: 'Lazer', icon: '🎮', color: '#DDA0DD' },
  { id: 'roupas', name: 'Roupas', icon: '👕', color: '#98D8C8' },
  { id: 'outros', name: 'Outros', icon: '📦', color: '#F7DC6F' }
];

export const budgetTips = [
  "💡 Regra 50/30/20: 50% necessidades, 30% desejos, 20% poupança",
  "🎯 Defina metas financeiras específicas e mensuráveis",
  "📱 Use aplicativos para acompanhar gastos em tempo real",
  "🛒 Faça uma lista antes de ir às compras",
  "💳 Evite compras por impulso - espere 24h antes de decidir",
  "🏦 Automatize suas poupanças e investimentos",
  "📊 Revise seu orçamento mensalmente",
  "🎁 Considere presentes caseiros ou experiências ao invés de objetos",
  "🔄 Renegocie contratos anuais (seguros, planos, etc.)",
  "💰 Crie um fundo de emergência equivalente a 6 meses de gastos"
];

export const budgetTemplates = [
  {
    id: 'conservador',
    name: 'Conservador',
    description: 'Para quem prioriza segurança financeira',
    allocations: {
      alimentacao: 25,
      moradia: 30,
      transporte: 15,
      saude: 10,
      educacao: 5,
      lazer: 5,
      roupas: 3,
      outros: 7
    }
  },
  {
    id: 'equilibrado',
    name: 'Equilibrado',
    description: 'Balanceamento entre necessidades e desejos',
    allocations: {
      alimentacao: 20,
      moradia: 25,
      transporte: 15,
      saude: 8,
      educacao: 8,
      lazer: 12,
      roupas: 5,
      outros: 7
    }
  },
  {
    id: 'jovem',
    name: 'Jovem Profissional',
    description: 'Para quem está começando a carreira',
    allocations: {
      alimentacao: 18,
      moradia: 35,
      transporte: 12,
      saude: 5,
      educacao: 10,
      lazer: 15,
      roupas: 3,
      outros: 2
    }
  },
  {
    id: 'familia',
    name: 'Família',
    description: 'Para famílias com filhos',
    allocations: {
      alimentacao: 30,
      moradia: 25,
      transporte: 15,
      saude: 12,
      educacao: 10,
      lazer: 5,
      roupas: 2,
      outros: 1
    }
  }
];

export const sampleExpenses = [
  { id: 1, description: 'Supermercado Extra', amount: 280.50, category: 'alimentacao', date: '2024-01-15' },
  { id: 2, description: 'Gasolina', amount: 120.00, category: 'transporte', date: '2024-01-14' },
  { id: 3, description: 'Aluguel', amount: 1200.00, category: 'moradia', date: '2024-01-01' },
  { id: 4, description: 'Consulta médica', amount: 150.00, category: 'saude', date: '2024-01-12' },
  { id: 5, description: 'Curso online', amount: 89.90, category: 'educacao', date: '2024-01-10' },
  { id: 6, description: 'Cinema', amount: 45.00, category: 'lazer', date: '2024-01-13' },
  { id: 7, description: 'Restaurante', amount: 85.00, category: 'alimentacao', date: '2024-01-11' },
  { id: 8, description: 'Uber', amount: 25.50, category: 'transporte', date: '2024-01-09' },
  { id: 9, description: 'Conta de luz', amount: 180.00, category: 'moradia', date: '2024-01-05' },
  { id: 10, description: 'Farmácia', amount: 65.80, category: 'saude', date: '2024-01-08' },
  { id: 11, description: 'Livros', amount: 120.00, category: 'educacao', date: '2024-01-07' },
  { id: 12, description: 'Streaming', amount: 29.90, category: 'lazer', date: '2024-01-06' },
  { id: 13, description: 'Camiseta', amount: 59.90, category: 'roupas', date: '2024-01-04' },
  { id: 14, description: 'Material de escritório', amount: 35.00, category: 'outros', date: '2024-01-03' }
];

export const sampleSavings = [
  { id: 1, description: 'Poupança de Emergência', amount: 500.00, date: '2024-01-10' },
  { id: 2, description: 'Investimento inicial', amount: 1000.00, date: '2024-01-02' }
];

export const sampleGoals = [
  { id: 1, name: 'Viagem para a Europa', targetAmount: 15000, currentAmount: 2500, deadline: '2025-12-31' },
  { id: 2, name: 'Comprar um MacBook Pro', targetAmount: 12000, currentAmount: 6000, deadline: '2024-10-30' },
  { id: 3, name: 'Entrada do Apartamento', targetAmount: 50000, currentAmount: 15000, deadline: '2026-06-01' }
];