import React from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LayoutDashboard, PiggyBank, Target as TargetIcon } from 'lucide-react';

import { BudgetOverview } from '@/components/BudgetOverview';
import { ExpenseForm } from '@/components/ExpenseForm';
import { ExpenseList } from '@/components/ExpenseList';
import { Charts } from '@/components/Charts';
import { BudgetTips } from '@/components/BudgetTips';
import { BudgetTemplates } from '@/components/BudgetTemplates';
import { Savings } from '@/components/Savings';
import { Goals } from '@/components/Goals';

export function Dashboard({ appData }) {
  const {
    budget,
    addExpense,
    deleteExpense,
    getCurrentMonthExpenses,
    getTotalSpent,
    getRemainingBudget,
    getExpensesByCategory,
    getWeeklyData,
    getMonthlyData,
    getYearlyData,
    savings,
    totalSavings,
    addSaving,
    deleteSaving,
    goals,
    addGoal,
    deleteGoal,
    addContributionToGoal,
    handleApplyTemplate
  } = appData;

  const currentMonthExpenses = getCurrentMonthExpenses();
  const totalSpent = getTotalSpent();
  const remainingBudget = getRemainingBudget();
  const expensesByCategory = getExpensesByCategory();
  const weeklyData = getWeeklyData();
  const monthlyData = getMonthlyData();
  const yearlyData = getYearlyData();

  return (
    <Tabs defaultValue="overview" className="w-full">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <TabsList className="grid w-full grid-cols-3 glass-card-dark border-white/20 p-2 h-auto">
          <TabsTrigger value="overview" className="text-white data-[state=active]:bg-white/20 py-2">
            <LayoutDashboard className="h-4 w-4 mr-2" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="savings" className="text-white data-[state=active]:bg-white/20 py-2">
            <PiggyBank className="h-4 w-4 mr-2" />
            Poupança
          </TabsTrigger>
          <TabsTrigger value="goals" className="text-white data-[state=active]:bg-white/20 py-2">
            <TargetIcon className="h-4 w-4 mr-2" />
            Metas
          </TabsTrigger>
        </TabsList>
      </motion.div>

      <motion.div
        key="overview"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
      >
        <TabsContent value="overview" className="mt-6">
          <BudgetOverview
            budget={budget}
            totalSpent={totalSpent}
            remainingBudget={remainingBudget}
          />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-1">
              <ExpenseForm onAddExpense={addExpense} />
            </div>
            <div className="lg:col-span-2">
              <ExpenseList
                expenses={currentMonthExpenses}
                onDeleteExpense={deleteExpense}
              />
            </div>
          </div>
          <div className="mb-8">
            <Charts
              expensesByCategory={expensesByCategory}
              weeklyData={weeklyData}
              monthlyData={monthlyData}
              yearlyData={yearlyData}
            />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <BudgetTips />
            <BudgetTemplates
              budget={budget}
              onApplyTemplate={handleApplyTemplate}
            />
          </div>
        </TabsContent>
      </motion.div>

      <motion.div
        key="savings"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
      >
        <TabsContent value="savings" className="mt-6">
          <Savings
            savings={savings}
            totalSavings={totalSavings}
            addSaving={addSaving}
            deleteSaving={deleteSaving}
          />
        </TabsContent>
      </motion.div>

      <motion.div
        key="goals"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
      >
        <TabsContent value="goals" className="mt-6">
          <Goals
            goals={goals}
            addGoal={addGoal}
            deleteGoal={deleteGoal}
            addContributionToGoal={addContributionToGoal}
          />
        </TabsContent>
      </motion.div>
    </Tabs>
  );
}