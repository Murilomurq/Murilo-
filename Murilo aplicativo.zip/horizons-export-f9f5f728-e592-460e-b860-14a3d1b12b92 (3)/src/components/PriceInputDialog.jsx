import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';

export function PriceInputDialog({ item, isOpen, onOpenChange, onConfirm }) {
  const [price, setPrice] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (item) {
      setPrice(item.price > 0 ? item.price.toString() : '');
    }
  }, [item]);

  const handleConfirm = () => {
    const numericPrice = parseFloat(price);
    if (isNaN(numericPrice) || numericPrice < 0) {
      toast({
        title: 'Preço Inválido',
        description: 'Por favor, insira um número válido para o preço.',
        variant: 'destructive',
      });
      return;
    }
    onConfirm(item.id, numericPrice);
    onOpenChange(false);
  };

  if (!item) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] modern-panel">
        <DialogHeader>
          <DialogTitle className="text-2xl">{item.name}</DialogTitle>
          <DialogDescription>
            Insira o preço do item para adicioná-lo ao carrinho.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <label htmlFor="price" className="text-sm font-medium text-muted-foreground">
            Preço (R$)
          </label>
          <input
            id="price"
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="modern-input mt-2 text-lg"
            placeholder="0.00"
            step="0.01"
            min="0"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleConfirm()}
          />
        </div>
        <DialogFooter>
          <button onClick={handleConfirm} className="primary-button w-full">
            Confirmar e Mover para o Carrinho
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}