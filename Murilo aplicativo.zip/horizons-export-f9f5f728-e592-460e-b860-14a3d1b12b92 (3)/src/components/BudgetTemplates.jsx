import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { LayoutTemplate as Template, Download } from 'lucide-react';
import { budgetTemplates, categories } from '@/data/budgetData';
import { useToast } from '@/components/ui/use-toast';

export function BudgetTemplates({ budget, onApplyTemplate }) {
  const { toast } = useToast();

  const getCategoryInfo = (categoryId) => {
    return categories.find(cat => cat.id === categoryId) || { name: 'Outros', icon: '📦' };
  };

  const handleApplyTemplate = (template) => {
    onApplyTemplate(template);
    toast({
      title: "Modelo aplicado!",
      description: `O modelo "${template.name}" foi aplicado ao seu orçamento`,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Card className="glass-card border-0">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Template className="h-5 w-5" />
            Modelos de Orçamento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {budgetTemplates.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Dialog>
                  <DialogTrigger asChild>
                    <Card className="glass-card-dark border-white/10 cursor-pointer hover:border-white/30 transition-all duration-300 hover:scale-105">
                      <CardContent className="p-4">
                        <h3 className="text-white font-semibold text-lg mb-2">
                          {template.name}
                        </h3>
                        <p className="text-white/70 text-sm mb-3">
                          {template.description}
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(template.allocations)
                            .sort(([,a], [,b]) => b - a)
                            .slice(0, 3)
                            .map(([categoryId, percentage]) => {
                              const categoryInfo = getCategoryInfo(categoryId);
                              return (
                                <span
                                  key={categoryId}
                                  className="text-xs bg-white/20 text-white px-2 py-1 rounded-full"
                                >
                                  {categoryInfo.icon} {percentage}%
                                </span>
                              );
                            })}
                        </div>
                      </CardContent>
                    </Card>
                  </DialogTrigger>
                  <DialogContent className="glass-card-dark border-white/20 text-white max-w-md">
                    <DialogHeader>
                      <DialogTitle className="text-white">
                        Modelo: {template.name}
                      </DialogTitle>
                      <DialogDescription className="text-white/70">
                        {template.description}
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-3 max-h-60 overflow-y-auto scrollbar-hide">
                      {Object.entries(template.allocations)
                        .sort(([,a], [,b]) => b - a)
                        .map(([categoryId, percentage]) => {
                          const categoryInfo = getCategoryInfo(categoryId);
                          const amount = (budget * percentage) / 100;
                          return (
                            <div key={categoryId} className="flex items-center justify-between p-2 glass-card border-white/10 rounded">
                              <div className="flex items-center gap-2">
                                <span className="text-lg">{categoryInfo.icon}</span>
                                <span className="text-white">{categoryInfo.name}</span>
                              </div>
                              <div className="text-right">
                                <div className="text-white font-medium">
                                  R$ {amount.toLocaleString('pt-BR', { 
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2 
                                  })}
                                </div>
                                <div className="text-white/60 text-sm">{percentage}%</div>
                              </div>
                            </div>
                          );
                        })}
                    </div>

                    <DialogFooter>
                      <Button
                        onClick={() => handleApplyTemplate(template)}
                        className="gradient-bg hover:opacity-90 transition-opacity"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Aplicar Modelo
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}