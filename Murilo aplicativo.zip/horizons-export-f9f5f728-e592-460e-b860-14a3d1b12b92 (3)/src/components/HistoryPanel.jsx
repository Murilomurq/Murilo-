import React from 'react';
import { motion } from 'framer-motion';
import { HistoryChart } from '@/components/HistoryChart';
import { itemCategories } from '@/data/shoppingData';
import { Calendar, History } from 'lucide-react';

export function HistoryPanel({ history }) {
  const sortedMonths = Object.keys(history).sort().reverse();

  if (sortedMonths.length === 0) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <History size={48} className="mx-auto mb-4" />
        <h3 className="text-xl">Nenhum Histórico Disponível</h3>
        <p>Complete uma compra para ver seu histórico aqui.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4 neon-text">Gráfico de Gastos Mensais</h2>
        <HistoryChart data={history} />
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-4 neon-text">Resumo Mensal</h2>
        <div className="space-y-6">
          {sortedMonths.map((month, index) => {
            const monthData = history[month];
            const topCategory = Object.entries(monthData.categories).sort(([, a], [, b]) => b - a)[0];
            const categoryInfo = itemCategories[topCategory[0]];

            return (
              <motion.div
                key={month}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="tech-panel p-6"
              >
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Calendar size={20} className="text-[var(--neon-cyan)]" />
                  {new Date(month + '-02').toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="tech-panel p-4 border-blue-500/10">
                    <p className="text-muted-foreground text-sm">Total Gasto</p>
                    <p className="text-2xl font-bold neon-text-magenta">R$ {monthData.totalSpent.toFixed(2)}</p>
                  </div>
                  <div className="tech-panel p-4 border-blue-500/10">
                    <p className="text-muted-foreground text-sm">Itens Comprados</p>
                    <p className="text-2xl font-bold neon-text-magenta">{monthData.totalItems}</p>
                  </div>
                  <div className="tech-panel p-4 border-blue-500/10">
                    <p className="text-muted-foreground text-sm">Categoria Principal</p>
                    <p className="text-xl font-bold neon-text-magenta flex items-center justify-center gap-2">
                      {categoryInfo.icon} {categoryInfo.name}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}