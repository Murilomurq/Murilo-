import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, Calendar } from 'lucide-react';
import { categories } from '@/data/budgetData';
import { useToast } from '@/components/ui/use-toast';

export function ExpenseList({ expenses, onDeleteExpense }) {
  const { toast } = useToast();

  const getCategoryInfo = (categoryId) => {
    return categories.find(cat => cat.id === categoryId) || { name: 'Outros', icon: '📦', color: '#F7DC6F' };
  };

  const handleDelete = (id, description) => {
    onDeleteExpense(id);
    toast({
      title: "Despesa removida",
      description: `"${description}" foi removida com sucesso`,
    });
  };

  if (expenses.length === 0) {
    return (
      <Card className="glass-card border-0">
        <CardContent className="p-8 text-center">
          <div className="text-6xl mb-4">💸</div>
          <p className="text-white/80 text-lg">Nenhuma despesa registrada este mês</p>
          <p className="text-white/60 text-sm mt-2">Adicione suas primeiras despesas para começar o controle</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card border-0">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Despesas do Mês ({expenses.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 max-h-96 overflow-y-auto scrollbar-hide">
        <AnimatePresence>
          {expenses.map((expense, index) => {
            const categoryInfo = getCategoryInfo(expense.category);
            return (
              <motion.div
                key={expense.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                className="glass-card-dark p-4 rounded-lg border border-white/10"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
                      style={{ backgroundColor: categoryInfo.color + '20' }}
                    >
                      {categoryInfo.icon}
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium">{expense.description}</p>
                      <p className="text-white/60 text-sm">{categoryInfo.name}</p>
                      <p className="text-white/40 text-xs">
                        {new Date(expense.date).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-white font-bold text-lg">
                      R$ {expense.amount.toLocaleString('pt-BR', { 
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2 
                      })}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(expense.id, expense.description)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}