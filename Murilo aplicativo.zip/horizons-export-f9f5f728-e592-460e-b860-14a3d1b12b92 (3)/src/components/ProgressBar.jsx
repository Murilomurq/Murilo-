import React from 'react';
import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';

export function ProgressBar({ value, className }) {
  const [progress, setProgress] = React.useState(0);

  React.useEffect(() => {
    const timer = setTimeout(() => setProgress(value), 500);
    return () => clearTimeout(timer);
  }, [value]);

  return (
    <Progress value={progress} className={className} />
  );
}