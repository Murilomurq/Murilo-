import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Target, Plus, Trash2, DollarSign } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { ProgressBar } from '@/components/ProgressBar';

export function Goals({ goals, addGoal, deleteGoal, addContributionToGoal }) {
  const [isAddGoalOpen, setIsAddGoalOpen] = useState(false);
  const [isContributeOpen, setIsContributeOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState(null);
  const [goalName, setGoalName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [deadline, setDeadline] = useState('');
  const [contributionAmount, setContributionAmount] = useState('');
  const { toast } = useToast();

  const handleAddGoal = (e) => {
    e.preventDefault();
    if (!goalName || !targetAmount || !deadline) {
      toast({ title: "Erro", description: "Preencha todos os campos da meta.", variant: "destructive" });
      return;
    }
    addGoal({ name: goalName, targetAmount: parseFloat(targetAmount), deadline });
    setGoalName('');
    setTargetAmount('');
    setDeadline('');
    setIsAddGoalOpen(false);
    toast({ title: "Sucesso!", description: "Nova meta criada!" });
  };

  const handleContribute = (e) => {
    e.preventDefault();
    if (!contributionAmount || !selectedGoal) return;
    const amount = parseFloat(contributionAmount);
    addContributionToGoal(selectedGoal.id, amount);
    setContributionAmount('');
    setIsContributeOpen(false);
    toast({ title: "Contribuição adicionada!", description: `R$ ${amount.toFixed(2)} adicionados à meta "${selectedGoal.name}".` });
  };

  const handleDelete = (id, name) => {
    deleteGoal(id);
    toast({ title: "Meta removida", description: `A meta "${name}" foi removida.` });
  };

  return (
    <div>
      <div className="flex justify-end mb-6">
        <Dialog open={isAddGoalOpen} onOpenChange={setIsAddGoalOpen}>
          <DialogTrigger asChild>
            <Button className="gradient-bg-5 hover:opacity-90 transition-opacity">
              <Plus className="h-4 w-4 mr-2" />
              Criar Nova Meta
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-card-dark border-white/20 text-white">
            <DialogHeader>
              <DialogTitle className="text-white">Criar Nova Meta Financeira</DialogTitle>
              <DialogDescription className="text-white/70">Defina seu próximo grande objetivo.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddGoal} className="space-y-4">
              <Input placeholder="Nome da meta (ex: Viagem dos Sonhos)" value={goalName} onChange={(e) => setGoalName(e.target.value)} className="glass-card border-white/20 text-white" />
              <Input type="number" placeholder="Valor Alvo (R$)" value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} className="glass-card border-white/20 text-white" />
              <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="glass-card border-white/20 text-white" />
              <DialogFooter>
                <Button type="submit" className="gradient-bg-5 hover:opacity-90 transition-opacity">Criar Meta</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence>
          {goals.map((goal, index) => {
            const progress = (goal.currentAmount / goal.targetAmount) * 100;
            return (
              <motion.div
                key={goal.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="glass-card border-0 h-full flex flex-col">
                  <CardHeader>
                    <CardTitle className="text-white flex justify-between items-start">
                      <span className="flex items-center gap-2"><Target className="h-5 w-5" /> {goal.name}</span>
                      <Button variant="ghost" size="icon" className="w-8 h-8 text-red-400 hover:bg-red-500/20" onClick={() => handleDelete(goal.id, goal.name)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <div className="mb-4">
                      <div className="flex justify-between items-end mb-1">
                        <span className="text-2xl font-bold text-white">R$ {goal.currentAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                        <span className="text-sm text-white/70">de R$ {goal.targetAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <ProgressBar value={progress} className="h-3 bg-white/20 [&>div]:gradient-bg-3" />
                      <div className="flex justify-between text-xs text-white/60 mt-1">
                        <span>{progress.toFixed(1)}%</span>
                        <span>Prazo: {new Date(goal.deadline + 'T00:00:00').toLocaleDateString('pt-BR')}</span>
                      </div>
                    </div>
                  </CardContent>
                  <div className="p-6 pt-0">
                    <Button
                      className="w-full gradient-bg-3 hover:opacity-90 transition-opacity"
                      onClick={() => {
                        setSelectedGoal(goal);
                        setIsContributeOpen(true);
                      }}
                    >
                      <DollarSign className="h-4 w-4 mr-2" />
                      Contribuir
                    </Button>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {goals.length === 0 && (
        <div className="text-center py-20 text-white/70">
          <Target className="h-16 w-16 mx-auto mb-4" />
          <h3 className="text-xl font-semibold">Nenhuma meta criada ainda.</h3>
          <p className="text-white/50">Crie sua primeira meta para começar a realizar seus sonhos!</p>
        </div>
      )}

      <Dialog open={isContributeOpen} onOpenChange={setIsContributeOpen}>
        <DialogContent className="glass-card-dark border-white/20 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">Contribuir para: {selectedGoal?.name}</DialogTitle>
            <DialogDescription className="text-white/70">Quanto você quer adicionar a esta meta?</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleContribute} className="space-y-4">
            <Input type="number" placeholder="Valor da Contribuição (R$)" value={contributionAmount} onChange={(e) => setContributionAmount(e.target.value)} className="glass-card border-white/20 text-white" />
            <DialogFooter>
              <Button type="submit" className="gradient-bg-3 hover:opacity-90 transition-opacity">Adicionar Contribuição</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}