import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lightbulb, RefreshCw } from 'lucide-react';
import { budgetTips } from '@/data/budgetData';

export function BudgetTips() {
  const [currentTip, setCurrentTip] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % budgetTips.length);
    }, 10000); // Muda a dica a cada 10 segundos

    return () => clearInterval(interval);
  }, []);

  const getRandomTip = () => {
    const randomIndex = Math.floor(Math.random() * budgetTips.length);
    setCurrentTip(randomIndex);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <Card className="glass-card border-0 relative overflow-hidden">
        <div className="absolute inset-0 gradient-bg-5 opacity-10" />
        <CardHeader className="relative z-10">
          <CardTitle className="text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5" />
              Dica de Orçamento
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={getRandomTip}
              className="text-white/80 hover:text-white hover:bg-white/10"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative z-10">
          <motion.div
            key={currentTip}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-white/90 text-lg leading-relaxed"
          >
            {budgetTips[currentTip]}
          </motion.div>
          <div className="flex justify-center mt-4 space-x-2">
            {budgetTips.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTip(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentTip 
                    ? 'bg-white scale-125' 
                    : 'bg-white/40 hover:bg-white/60'
                }`}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}