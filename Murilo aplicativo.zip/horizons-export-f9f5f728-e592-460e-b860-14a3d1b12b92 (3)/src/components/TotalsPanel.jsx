import React from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';

export function TotalsPanel({ totalCart }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="modern-panel p-6 space-y-4"
    >
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <ShoppingCart className="text-accent" size={28} />
          <span className="text-xl font-medium text-accent">Total no Carrinho</span>
        </div>
        <span className="text-3xl font-bold text-accent">
          R$ {totalCart.toFixed(2)}
        </span>
      </div>
    </motion.div>
  );
}