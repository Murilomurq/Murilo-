import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line } from 'recharts';
import { categories } from '@/data/budgetData';
import { BarChart3, PieChart as PieChartIcon, TrendingUp } from 'lucide-react';

export function Charts({ 
  expensesByCategory, 
  weeklyData, 
  monthlyData, 
  yearlyData 
}) {
  const getCategoryInfo = (categoryId) => {
    return categories.find(cat => cat.id === categoryId) || { name: 'Outros', color: '#F7DC6F' };
  };

  const pieData = Object.entries(expensesByCategory).map(([categoryId, amount]) => {
    const categoryInfo = getCategoryInfo(categoryId);
    return {
      name: categoryInfo.name,
      value: amount,
      color: categoryInfo.color
    };
  });

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card-dark p-3 rounded-lg border border-white/20">
          <p className="text-white font-medium">{label}</p>
          <p className="text-white/80">
            R$ {payload[0].value.toLocaleString('pt-BR', { 
              minimumFractionDigits: 2,
              maximumFractionDigits: 2 
            })}
          </p>
        </div>
      );
    }
    return null;
  };

  const formatWeeklyData = weeklyData.map(item => ({
    ...item,
    week: `Semana ${new Date(item.week).getDate()}/${new Date(item.week).getMonth() + 1}`
  }));

  const formatMonthlyData = monthlyData.map(item => ({
    ...item,
    month: new Date(item.month + '-01').toLocaleDateString('pt-BR', { 
      month: 'short', 
      year: 'numeric' 
    })
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="glass-card border-0">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Análise Visual dos Gastos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="category" className="w-full">
            <TabsList className="grid w-full grid-cols-4 glass-card-dark border-white/20">
              <TabsTrigger value="category" className="text-white data-[state=active]:bg-white/20">
                <PieChartIcon className="h-4 w-4 mr-2" />
                Categorias
              </TabsTrigger>
              <TabsTrigger value="weekly" className="text-white data-[state=active]:bg-white/20">
                <BarChart3 className="h-4 w-4 mr-2" />
                Semanal
              </TabsTrigger>
              <TabsTrigger value="monthly" className="text-white data-[state=active]:bg-white/20">
                <TrendingUp className="h-4 w-4 mr-2" />
                Mensal
              </TabsTrigger>
              <TabsTrigger value="yearly" className="text-white data-[state=active]:bg-white/20">
                <TrendingUp className="h-4 w-4 mr-2" />
                Anual
              </TabsTrigger>
            </TabsList>

            <TabsContent value="category" className="mt-6">
              <div className="h-80">
                {pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-white/60">
                    <p>Nenhum dado disponível para este período</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="weekly" className="mt-6">
              <div className="h-80">
                {formatWeeklyData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={formatWeeklyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis 
                        dataKey="week" 
                        stroke="rgba(255,255,255,0.6)"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="rgba(255,255,255,0.6)"
                        fontSize={12}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="amount" fill="url(#gradient1)" radius={[4, 4, 0, 0]} />
                      <defs>
                        <linearGradient id="gradient1" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#667eea" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#764ba2" stopOpacity={0.8}/>
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-white/60">
                    <p>Nenhum dado semanal disponível</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="monthly" className="mt-6">
              <div className="h-80">
                {formatMonthlyData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={formatMonthlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis 
                        dataKey="month" 
                        stroke="rgba(255,255,255,0.6)"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="rgba(255,255,255,0.6)"
                        fontSize={12}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Line 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="#4facfe" 
                        strokeWidth={3}
                        dot={{ fill: '#4facfe', strokeWidth: 2, r: 6 }}
                        activeDot={{ r: 8, stroke: '#4facfe', strokeWidth: 2 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-white/60">
                    <p>Nenhum dado mensal disponível</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="yearly" className="mt-6">
              <div className="h-80">
                {yearlyData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={yearlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis 
                        dataKey="year" 
                        stroke="rgba(255,255,255,0.6)"
                        fontSize={12}
                      />
                      <YAxis 
                        stroke="rgba(255,255,255,0.6)"
                        fontSize={12}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="amount" fill="url(#gradient2)" radius={[4, 4, 0, 0]} />
                      <defs>
                        <linearGradient id="gradient2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#43e97b" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#38f9d7" stopOpacity={0.8}/>
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-white/60">
                    <p>Nenhum dado anual disponível</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </motion.div>
  );
}