import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Trash2, Edit } from 'lucide-react';
import { itemCategories } from '@/data/shoppingData';

export function ShoppingList({ items, onToggleItem, onDeleteItem, onEditPrice }) {
  if (items.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <p className="text-lg">Nenhum item aqui.</p>
      </div>
    );
  }

  const handleToggle = (item) => {
    if (!item.inCart && item.price === 0) {
      onEditPrice(item);
    } else {
      onToggleItem(item.id);
    }
  };

  return (
    <div className="space-y-3 max-h-[500px] overflow-y-auto scrollbar-hide pr-2">
      <AnimatePresence>
        {items.map((item, index) => {
          const categoryInfo = itemCategories[item.category] || itemCategories.outros;
          return (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: 50, transition: { duration: 0.3 } }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className={`modern-panel p-4 flex items-center justify-between transition-all duration-300 ${item.inCart ? 'item-checked' : ''}`}
            >
              <div className="flex items-center gap-4 flex-1 min-w-0">
                <button
                  onClick={() => handleToggle(item)}
                  className={`w-7 h-7 rounded-full flex items-center justify-center border-2 transition-all duration-300 flex-shrink-0 ${
                    item.inCart
                      ? 'bg-accent border-accent'
                      : 'border-muted-foreground/50 hover:border-accent'
                  }`}
                >
                  {item.inCart && <Check size={18} className="text-accent-foreground" />}
                </button>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-lg truncate item-name">
                    {item.name}
                  </p>
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ backgroundColor: `${categoryInfo.color}20`, color: categoryInfo.color }}
                  >
                    {categoryInfo.name}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-3 ml-2">
                {item.price > 0 && (
                  <p className="font-mono text-lg text-foreground font-semibold">
                    R${item.price.toFixed(2)}
                  </p>
                )}
                {item.inCart && (
                   <button
                    onClick={() => onEditPrice(item)}
                    className="text-muted-foreground hover:text-accent transition-colors"
                  >
                    <Edit size={18} />
                  </button>
                )}
                <button
                  onClick={() => onDeleteItem(item.id)}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}