import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PiggyBank, Plus, Trash2, TrendingUp } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export function Savings({ savings, totalSavings, addSaving, deleteSaving }) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const { toast } = useToast();

  const handleAddSaving = (e) => {
    e.preventDefault();
    if (!description || !amount) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive"
      });
      return;
    }
    addSaving({ description, amount: parseFloat(amount) });
    setDescription('');
    setAmount('');
    toast({
      title: "Sucesso!",
      description: "Poupança adicionada com sucesso."
    });
  };

  const handleDelete = (id, desc) => {
    deleteSaving(id);
    toast({
      title: "Poupança removida",
      description: `"${desc}" foi removida com sucesso.`
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1 space-y-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Total Poupado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-white gradient-text bg-gradient-to-r from-green-400 to-blue-500">
                R$ {totalSavings.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Adicionar Poupança
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddSaving} className="space-y-4">
                <Input
                  placeholder="Descrição (ex: Fundo de Emergência)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="glass-card-dark border-white/20 text-white placeholder:text-white/60"
                />
                <Input
                  type="number"
                  step="0.01"
                  placeholder="Valor (R$)"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="glass-card-dark border-white/20 text-white placeholder:text-white/60"
                />
                <Button type="submit" className="w-full gradient-bg-4 hover:opacity-90 transition-opacity">
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      <motion.div className="lg:col-span-2" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
        <Card className="glass-card border-0">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <PiggyBank className="h-5 w-5" />
              Histórico de Poupança
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-[450px] overflow-y-auto scrollbar-hide">
            <AnimatePresence>
              {savings.length > 0 ? savings.map((saving, index) => (
                <motion.div
                  key={saving.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="glass-card-dark p-4 rounded-lg border border-white/10 flex items-center justify-between"
                >
                  <div>
                    <p className="text-white font-medium">{saving.description}</p>
                    <p className="text-white/60 text-sm">{new Date(saving.date).toLocaleDateString('pt-BR')}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-green-400 font-bold text-lg">
                      + R$ {saving.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(saving.id, saving.description)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              )) : (
                <div className="text-center py-10 text-white/70">
                  <PiggyBank className="h-12 w-12 mx-auto mb-4" />
                  <p>Nenhuma poupança registrada ainda.</p>
                  <p className="text-sm text-white/50">Comece a poupar para ver seu histórico aqui.</p>
                </div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}