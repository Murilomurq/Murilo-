import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, TrendingUp, TrendingDown, Target } from 'lucide-react';

export function BudgetOverview({ budget, totalSpent, remainingBudget }) {
  const spentPercentage = (totalSpent / budget) * 100;
  const isOverBudget = remainingBudget < 0;

  const cards = [
    {
      title: 'Orçamento Mensal',
      value: budget,
      icon: Target,
      gradient: 'gradient-bg',
      prefix: 'R$'
    },
    {
      title: 'Total Gasto',
      value: totalSpent,
      icon: TrendingUp,
      gradient: 'gradient-bg-2',
      prefix: 'R$'
    },
    {
      title: 'Saldo Restante',
      value: Math.abs(remainingBudget),
      icon: isOverBudget ? TrendingDown : DollarSign,
      gradient: isOverBudget ? 'gradient-bg-2' : 'gradient-bg-4',
      prefix: isOverBudget ? '-R$' : 'R$'
    },
    {
      title: 'Percentual Gasto',
      value: spentPercentage.toFixed(1),
      icon: TrendingUp,
      gradient: spentPercentage > 80 ? 'gradient-bg-2' : 'gradient-bg-3',
      prefix: '',
      suffix: '%'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className="glass-card border-0 overflow-hidden relative">
            <div className={`absolute inset-0 ${card.gradient} opacity-10`} />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
              <CardTitle className="text-sm font-medium text-white/80">
                {card.title}
              </CardTitle>
              <card.icon className="h-4 w-4 text-white/60" />
            </CardHeader>
            <CardContent className="relative z-10">
              <div className="text-2xl font-bold text-white">
                {card.prefix}{card.value.toLocaleString('pt-BR', { 
                  minimumFractionDigits: card.prefix.includes('R$') ? 2 : 0,
                  maximumFractionDigits: card.prefix.includes('R$') ? 2 : 1
                })}{card.suffix || ''}
              </div>
              <div className="w-full bg-white/20 rounded-full h-2 mt-3">
                <motion.div
                  className={`h-2 rounded-full ${card.gradient}`}
                  initial={{ width: 0 }}
                  animate={{ 
                    width: card.title === 'Percentual Gasto' 
                      ? `${Math.min(spentPercentage, 100)}%` 
                      : '100%' 
                  }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}