import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Settings, DollarSign, Calendar } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export function BudgetSettings({ budget, setBudget, currentMonth, setCurrentMonth }) {
  const [newBudget, setNewBudget] = useState(budget);
  const [newMonth, setNewMonth] = useState(currentMonth);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const handleSave = () => {
    setBudget(parseFloat(newBudget));
    setCurrentMonth(newMonth);
    setIsOpen(false);
    toast({
      title: "Configurações salvas!",
      description: "Suas configurações de orçamento foram atualizadas",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="glass-card-dark border-white/20 text-white hover:bg-white/10">
            <Settings className="h-4 w-4 mr-2" />
            Configurações
          </Button>
        </DialogTrigger>
        <DialogContent className="glass-card-dark border-white/20 text-white">
          <DialogHeader>
            <DialogTitle className="text-white">Configurações do Orçamento</DialogTitle>
            <DialogDescription className="text-white/70">
              Ajuste seu orçamento mensal e período de análise
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-white text-sm font-medium mb-2 flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Orçamento Mensal (R$)
              </label>
              <Input
                type="number"
                step="0.01"
                value={newBudget}
                onChange={(e) => setNewBudget(e.target.value)}
                className="glass-card border-white/20 text-white"
                placeholder="Digite seu orçamento mensal"
              />
            </div>
            
            <div>
              <label className="text-white text-sm font-medium mb-2 flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Mês de Referência
              </label>
              <Input
                type="month"
                value={newMonth}
                onChange={(e) => setNewMonth(e.target.value)}
                className="glass-card border-white/20 text-white"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsOpen(false)}
              className="glass-card border-white/20 text-white hover:bg-white/10"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSave}
              className="gradient-bg hover:opacity-90 transition-opacity"
            >
              Salvar Configurações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}