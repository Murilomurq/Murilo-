import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="tech-panel p-3 border border-blue-500/50">
        <p className="label font-bold text-lg neon-text">{label}</p>
        <p className="intro text-foreground">
          {`Total Gasto: R$ ${payload[0].value.toFixed(2)}`}
        </p>
      </div>
    );
  }
  return null;
};

export function HistoryChart({ data }) {
  const chartData = Object.entries(data)
    .map(([month, values]) => ({
      month: new Date(month + '-02').toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' }),
      totalSpent: values.totalSpent,
    }))
    .sort((a, b) => new Date(a.month) - new Date(b.month));

  return (
    <div className="tech-panel p-4 h-80">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
          <defs>
            <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="var(--neon-cyan)" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="var(--neon-cyan)" stopOpacity={0.1}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsla(217, 33%, 17%, 0.5)" />
          <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
          <YAxis stroke="hsl(var(--muted-foreground))" />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsla(205, 100%, 50%, 0.1)' }} />
          <Bar dataKey="totalSpent" fill="url(#colorUv)" name="Total Gasto" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}