import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { itemCategories } from '@/data/shoppingData';
import { useToast } from '@/components/ui/use-toast';

export function AddItemForm({ onAddItem }) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('alimentos');
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) {
      toast({
        title: 'Erro',
        description: 'O nome do item não pode estar vazio.',
        variant: 'destructive',
      });
      return;
    }
    onAddItem({ name, category });
    setName('');
    toast({
      title: 'Item Adicionado!',
      description: `${name} foi adicionado à sua lista.`,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="modern-panel p-6"
    >
      <h2 className="text-xl font-bold mb-4 text-foreground">Adicionar Novo Item</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Nome do item..."
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="modern-input"
        />
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="modern-input w-full"
        >
          {Object.entries(itemCategories).map(([key, { name, icon }]) => (
            <option key={key} value={key} className="bg-background text-foreground">
              {icon} {name}
            </option>
          ))}
        </select>
        <button type="submit" className="primary-button w-full flex items-center justify-center gap-2">
          <Plus size={20} />
          Adicionar à Lista
        </button>
      </form>
    </motion.div>
  );
}