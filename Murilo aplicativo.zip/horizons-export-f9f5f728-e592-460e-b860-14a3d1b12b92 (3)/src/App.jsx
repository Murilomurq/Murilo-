import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShoppingCart, ListChecks, PackagePlus } from 'lucide-react';

import { useShoppingList } from '@/hooks/useShoppingList';
import { AddItemForm } from '@/components/AddItemForm';
import { ShoppingList } from '@/components/ShoppingList';
import { TotalsPanel } from '@/components/TotalsPanel';
import { PriceInputDialog } from '@/components/PriceInputDialog';

function App() {
  const {
    addItem,
    toggleItem,
    deleteItem,
    updateItemPrice,
    getItemsByStatus,
    getTotals,
  } = useShoppingList();

  const [selectedItem, setSelectedItem] = useState(null);
  const [isPriceModalOpen, setPriceModalOpen] = useState(false);

  const handleEditPrice = (item) => {
    setSelectedItem(item);
    setPriceModalOpen(true);
  };
  
  const handleConfirmPrice = (id, price) => {
    updateItemPrice(id, price);
  };

  const { inCart, toBuy } = getItemsByStatus;
  const { totalCartValue } = getTotals;

  return (
    <>
      <Helmet>
        <title>Lista de Compras Inteligente</title>
        <meta name="description" content="Um aplicativo de lista de compras moderno para organizar suas compras com inteligência e controle de gastos." />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
      </Helmet>
      
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <motion.header
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-2 text-primary flex items-center justify-center gap-3">
              <ListChecks size={40} />
              Minha Lista de Compras
            </h1>
            <p className="text-muted-foreground text-lg">Planeje, compre e controle seus gastos.</p>
          </motion.header>

          <main className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-1 flex flex-col gap-8">
              <AddItemForm onAddItem={addItem} />
              <TotalsPanel totalCart={totalCartValue} />
            </div>
            
            <div className="lg:col-span-2">
              <Tabs defaultValue="tobuy" className="w-full">
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <TabsList className="grid w-full grid-cols-2 modern-panel p-1 h-auto mb-6">
                    <TabsTrigger value="tobuy" className="text-base data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md rounded-lg py-2">
                      <PackagePlus className="h-5 w-5 mr-2" />
                      Faltando ({toBuy.length})
                    </TabsTrigger>
                    <TabsTrigger value="incart" className="text-base data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md rounded-lg py-2">
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      No Carrinho ({inCart.length})
                    </TabsTrigger>
                  </TabsList>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <TabsContent value="tobuy">
                    <ShoppingList items={toBuy} onToggleItem={handleEditPrice} onDeleteItem={deleteItem} onEditPrice={handleEditPrice} />
                  </TabsContent>
                  <TabsContent value="incart">
                    <ShoppingList items={inCart} onToggleItem={toggleItem} onDeleteItem={deleteItem} onEditPrice={handleEditPrice} />
                  </TabsContent>
                </motion.div>
              </Tabs>
            </div>
          </main>
        </div>
        <Toaster />
        <PriceInputDialog 
          item={selectedItem}
          isOpen={isPriceModalOpen}
          onOpenChange={setPriceModalOpen}
          onConfirm={handleConfirmPrice}
        />
      </div>
    </>
  );
}

export default App;