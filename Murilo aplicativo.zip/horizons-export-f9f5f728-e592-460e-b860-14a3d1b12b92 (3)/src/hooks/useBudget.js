import { useState, useEffect } from 'react';
import { sampleExpenses, sampleSavings, sampleGoals } from '@/data/budgetData';

export function useBudget() {
  const [budget, setBudget] = useState(() => {
    const saved = localStorage.getItem('budget');
    return saved ? JSON.parse(saved) : 3000;
  });

  const [expenses, setExpenses] = useState(() => {
    const saved = localStorage.getItem('expenses');
    return saved ? JSON.parse(saved) : sampleExpenses;
  });

  const [savings, setSavings] = useState(() => {
    const saved = localStorage.getItem('savings');
    return saved ? JSON.parse(saved) : sampleSavings;
  });

  const [goals, setGoals] = useState(() => {
    const saved = localStorage.getItem('goals');
    return saved ? JSON.parse(saved) : sampleGoals;
  });

  const [currentMonth, setCurrentMonth] = useState(() => {
    const saved = localStorage.getItem('currentMonth');
    return saved ? JSON.parse(saved) : new Date().toISOString().slice(0, 7);
  });

  useEffect(() => {
    localStorage.setItem('budget', JSON.stringify(budget));
  }, [budget]);

  useEffect(() => {
    localStorage.setItem('expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('savings', JSON.stringify(savings));
  }, [savings]);

  useEffect(() => {
    localStorage.setItem('goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('currentMonth', JSON.stringify(currentMonth));
  }, [currentMonth]);

  const addExpense = (expense) => {
    const newExpense = {
      ...expense,
      id: Date.now(),
      date: new Date().toISOString().slice(0, 10)
    };
    setExpenses(prev => [newExpense, ...prev]);
  };

  const deleteExpense = (id) => {
    setExpenses(prev => prev.filter(expense => expense.id !== id));
  };

  const addSaving = (saving) => {
    const newSaving = {
      ...saving,
      id: Date.now(),
      date: new Date().toISOString().slice(0, 10)
    };
    setSavings(prev => [newSaving, ...prev]);
  };

  const deleteSaving = (id) => {
    setSavings(prev => prev.filter(saving => saving.id !== id));
  };

  const addGoal = (goal) => {
    const newGoal = {
      ...goal,
      id: Date.now(),
      currentAmount: 0
    };
    setGoals(prev => [newGoal, ...prev]);
  };

  const deleteGoal = (id) => {
    setGoals(prev => prev.filter(goal => goal.id !== id));
  };

  const addContributionToGoal = (goalId, amount) => {
    setGoals(prev => prev.map(goal => 
      goal.id === goalId 
        ? { ...goal, currentAmount: goal.currentAmount + amount }
        : goal
    ));
  };

  const getCurrentMonthExpenses = () => {
    return expenses.filter(expense => 
      expense.date.startsWith(currentMonth)
    );
  };

  const getTotalSpent = () => {
    return getCurrentMonthExpenses().reduce((total, expense) => total + expense.amount, 0);
  };

  const getRemainingBudget = () => {
    return budget - getTotalSpent();
  };

  const getTotalSavings = () => {
    return savings.reduce((total, saving) => total + saving.amount, 0);
  };

  const getExpensesByCategory = () => {
    const monthlyExpenses = getCurrentMonthExpenses();
    const categoryTotals = {};
    
    monthlyExpenses.forEach(expense => {
      categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;
    });
    
    return categoryTotals;
  };

  const getWeeklyData = () => {
    const monthlyExpenses = getCurrentMonthExpenses();
    const weeklyData = {};
    
    monthlyExpenses.forEach(expense => {
      const date = new Date(expense.date);
      const weekStart = new Date(date.setDate(date.getDate() - date.getDay()));
      const weekKey = weekStart.toISOString().slice(0, 10);
      
      weeklyData[weekKey] = (weeklyData[weekKey] || 0) + expense.amount;
    });
    
    return Object.entries(weeklyData).map(([week, amount]) => ({
      week,
      amount
    })).sort((a, b) => new Date(a.week) - new Date(b.week));
  };

  const getMonthlyData = () => {
    const monthlyData = {};
    
    expenses.forEach(expense => {
      const month = expense.date.slice(0, 7);
      monthlyData[month] = (monthlyData[month] || 0) + expense.amount;
    });
    
    return Object.entries(monthlyData).map(([month, amount]) => ({
      month,
      amount
    })).sort((a, b) => new Date(a.month) - new Date(b.month));
  };

  const getYearlyData = () => {
    const yearlyData = {};
    
    expenses.forEach(expense => {
      const year = expense.date.slice(0, 4);
      yearlyData[year] = (yearlyData[year] || 0) + expense.amount;
    });
    
    return Object.entries(yearlyData).map(([year, amount]) => ({
      year,
      amount
    })).sort((a, b) => parseInt(a.year) - parseInt(b.year));
  };

  return {
    budget,
    setBudget,
    expenses,
    savings,
    goals,
    currentMonth,
    setCurrentMonth,
    addExpense,
    deleteExpense,
    addSaving,
    deleteSaving,
    addGoal,
    deleteGoal,
    addContributionToGoal,
    getCurrentMonthExpenses,
    getTotalSpent,
    getRemainingBudget,
    getTotalSavings,
    getExpensesByCategory,
    getWeeklyData,
    getMonthlyData,
    getYearlyData
  };
}