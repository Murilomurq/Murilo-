import { useState, useEffect, useMemo } from 'react';
import { sampleItems } from '@/data/shoppingData';

export const useShoppingList = () => {
  const [items, setItems] = useState(() => {
    const savedItems = localStorage.getItem('shoppingItems');
    // Initialize prices to 0 if they don't exist for items not in cart
    const initialItems = savedItems ? JSON.parse(savedItems) : sampleItems;
    return initialItems.map(item => ({
        ...item,
        price: item.price || 0,
    }));
  });

  useEffect(() => {
    localStorage.setItem('shoppingItems', JSON.stringify(items));
  }, [items]);

  const addItem = (item) => {
    const newItem = {
      ...item,
      id: Date.now(),
      inCart: false,
      price: 0,
      date: new Date().toISOString().slice(0, 10),
    };
    setItems(prev => [newItem, ...prev]);
  };

  const updateItemPrice = (id, price) => {
    setItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, price, inCart: true } : item
      )
    );
  };
  
  const toggleItem = (id) => {
    setItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, inCart: !item.inCart } : item
      )
    );
  };

  const deleteItem = (id) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const getItemsByStatus = useMemo(() => {
    const inCart = items.filter(item => item.inCart);
    const toBuy = items.filter(item => !item.inCart);
    return { inCart, toBuy };
  }, [items]);

  const getTotals = useMemo(() => {
    const totalCartValue = getItemsByStatus.inCart.reduce((sum, item) => sum + (item.price || 0), 0);
    return { totalCartValue };
  }, [items, getItemsByStatus]);

  return {
    items,
    addItem,
    toggleItem,
    deleteItem,
    updateItemPrice,
    getItemsByStatus,
    getTotals,
  };
};